http_path = "."
project_path = "."
css_dir = "."
sass_dir = "."
images_dir = "."
javascripts_dir = "."

output_style = :nested #(environment == :production) ? :compact : :nested
relative_assets = false
line_comments = false #(environment == :production) ? false : true
